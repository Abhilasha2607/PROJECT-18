//Global Variables
var PLAY = 1;
var END = 0;
var gameState = PLAY;


var monkey,banana,stone;
var gameOver,restart,ground;
var Monkey_01,Monkey_02,Monkey_03,Monkey_04,Monkey_05,Monkey_06,
    Monkey_07,Monkey_08,Monkey_09,Monkey_10;
var jungle,invisibleGround;

var count = 0;

function preload(){
  Monkey_01 = loadImage("Monkey_01.png");
  Monkey_02 = loadImage("Monkey_02.png");
  Monkey_03 = loadImage("Monkey_03.png");
  Monkey_04  = loadImage("Monkey_04.png");
  Monkey_05  = loadImage("Monkey_05.png");
 Monkey_06 = loadImage("Monkey_06.png");
  Monkey_07 = loadImage("Monkey_07.png"); 
  Monkey_07 = loadImage("Monkey_08.png"); 
  Monkey_07 = loadImage("Monkey_09.png"); 
  Monkey_07 = loadImage("Monkey_10.png"); 
  restart1 = loadImage("restart.png");
  gameOver1 = loadImage("gameOver.png");
  jungle = loadImage("jungle.png");
  stone =  loadImage("gameOver.png");
}


function setup() {
  createCanvas(600,300);
  monkey = createSprite(50,180,20,50);
  monkey.addImage("monkey",Monkey_01,Monkey_02,Monkey_03,Monkey_04,
                  Monkey_05,Monkey_06,
    Monkey_07,Monkey_08,Monkey_09,Monkey_10);
  monkey.scale = 0.5;
  
  
  ground = createSprite(200,180,400,20);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /2;
  
  invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
  
  restart = createSprite(330,130);
  restart.addImage("restart",restart1);
  restart.visible = false;
  restart.scale = 0.5;
  
  
  
  StonesGroup = newGroup();
  BananasGroup = newGroup();
  score = 0;
  
  
}


function draw(){
 background(255); 
   text("Score: "+ count, 500,50);
  
  if (gameState === PLAY){
  count = count + Math.round(getFrameRate()/60);  
     ground.velocityX = -(4+3*count/100);
    
    monkey.velocityY = monkey.velocityY +0.5;
  }
    
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  
    monkey.collide(invisibleGround);
  spawnStones();
  spawnBananas();
    
    
     if(StonesGroup.isTouching(monkey)) {
        
        score = score - 1;
        
        }
    if (BananasGroup.isTouching(monke)) {
      score = score+1;
    }
  
  if(mousePressedOver(restart)) {
    reset();
  }
  
  drawSprites();
  spawnStones();
  spawnBananas();
}
function reset(){
  gameState = PLAY;
  
  gameOver.visible = false;
  restart.visible = false;
  
  BananasGroup = destroEach();
  StonesGroup = destroyEach();
  
  
  
  count = 0;
  
}
function spawnStones(){
 
  if (frameCount % 60 === 0) {
    var stones= createSprite(600,165,10,40);
    stone.y = Math.round(random(100,120));
    stone.addImage(stoneImage);
   stone.scale = 0.5;
    stone.velocityX = -(3+3*count/100);
    
     //assign lifetime to the variable
    stone.lifetime = 200;
 
    StonesGroup.add(stone);
  }
  
  
}
function spawnBananas(){
  if(frameCount % 60 === 0) {
    var bananas = createSprite(600,15,10,40);
    banana.velocityX = -(4+3*count/100);
    banana.scale = 0.5;
   banana.lifetime = 300;
    //add each banana to the group
    bananaGroup.add(banana);
  }
}